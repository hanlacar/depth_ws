"""Camera YOLO inference tests."""
