"""Thirty-hertz dry-run route follower. MCU control is impossible by default."""

import csv
import math
import time

from diagnostic_msgs.msg import DiagnosticArray, DiagnosticStatus
from geometry_msgs.msg import PointStamped, PoseStamped, PoseWithCovarianceStamped
from nav_msgs.msg import Path
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, Float32, Int32, String

from .models import Pose2D, RoutePoint
from .ros_helpers import quaternion_from_yaw, safe_shutdown, stamp_seconds, status, yaw_from_quaternion
from .route_follower_core import RouteFollower


def load_route(path):
    points = []
    with open(path, newline="", encoding="utf-8") as stream:
        for position, row in enumerate(csv.DictReader(stream)):
            points.append(RoutePoint(
                int(row.get("route_index", row.get("index", position))),
                float(row.get("map_x_m", row.get("x"))),
                float(row.get("map_y_m", row.get("y"))),
                float(row.get("yaw_rad", row.get("yaw", 0.0))),
                int(row.get("direction") or 1),
                float(row.get("drive_level", 1.0)), row.get("mission_marker", ""),
                row.get("section_id", "")))
    return points


class RouteFollowerNode(Node):
    def __init__(self):
        super().__init__("route_follower")
        for name, default in (("route_path", ""), ("enable_control", False),
                              ("dry_run", True), ("user_approved", False),
                              ("pose_timeout_s", 0.15)):
            self.declare_parameter(name, default)
        path = str(self.get_parameter("route_path").value)
        self.route = load_route(path) if path else []
        self.core = RouteFollower()
        self.pose = None
        self.pose_receipt = None
        self.safety_ready = False
        self.mission_stop = True
        self.mission_speed_limit = 0.0
        self.pub_drive = self.create_publisher(Float32, "/slam_drive", 10)
        self.pub_wheel = self.create_publisher(Int32, "/slam_wheel", 10)
        self.pub_preview_drive = self.create_publisher(
            Float32, "/depth_slam/dry_run/drive", 10)
        self.pub_preview_wheel = self.create_publisher(
            Int32, "/depth_slam/dry_run/wheel", 10)
        self.pub_path = self.create_publisher(Path, "/depth_slam/route/reference_path", 10)
        self.pub_target = self.create_publisher(PointStamped, "/depth_slam/route/target_point", 10)
        self.pub_cross = self.create_publisher(Float32, "/depth_slam/route/cross_track_error", 10)
        self.pub_heading = self.create_publisher(Float32, "/depth_slam/route/heading_error", 10)
        self.pub_progress = self.create_publisher(Float32, "/depth_slam/route/progress", 10)
        self.pub_state = self.create_publisher(String, "/depth_slam/route/controller_state", 10)
        self.pub_diag = self.create_publisher(
            DiagnosticArray, "/depth_slam/route/controller_diagnostics", 10)
        self.create_subscription(PoseWithCovarianceStamped, "/depth_slam/localization/pose", self.on_pose, 10)
        self.create_subscription(String, "/depth_slam/safety/state",
                                 lambda m: setattr(self, "safety_ready", m.data == "READY"), 10)
        self.create_subscription(Bool, "/depth_slam/mission/stop_required",
                                 lambda m: setattr(self, "mission_stop", bool(m.data)), 10)
        self.create_subscription(Float32, "/depth_slam/mission/speed_limit",
                                 lambda m: setattr(self, "mission_speed_limit", max(0.0, float(m.data))), 10)
        self.create_timer(1.0/30.0, self.tick)
        self.publish_reference_path()

    def publish_reference_path(self):
        message = Path()
        message.header.frame_id = "map"
        message.header.stamp = self.get_clock().now().to_msg()
        for point in self.route:
            pose = PoseStamped()
            pose.header = message.header
            pose.pose.position.x, pose.pose.position.y = point.x, point.y
            pose.pose.orientation = quaternion_from_yaw(point.yaw)
            message.poses.append(pose)
        self.pub_path.publish(message)

    def on_pose(self, message):
        p = message.pose.pose.position
        self.pose = Pose2D(p.x, p.y, yaw_from_quaternion(message.pose.pose.orientation),
                           stamp_seconds(message.header.stamp))
        self.pose_receipt = time.monotonic()

    def tick(self):
        stale = (self.pose is None or self.pose_receipt is None or
                 time.monotonic()-self.pose_receipt >
                 float(self.get_parameter("pose_timeout_s").value))
        channel_enabled = (bool(self.get_parameter("enable_control").value) and
                           not bool(self.get_parameter("dry_run").value) and
                           bool(self.get_parameter("user_approved").value))
        allow = not stale and self.safety_ready and not self.mission_stop and channel_enabled
        pose = self.pose or Pose2D(0.0, 0.0, 0.0, 0.0)
        result = self.core.compute(pose, self.route, allow_motion=not stale)
        reason = "STALE_POSE" if stale else result.reason
        requested_drive = math.copysign(
            min(abs(result.drive), self.mission_speed_limit), result.drive)
        preview_drive = 0.0 if stale or result.stop_required or self.mission_stop else requested_drive
        self.pub_preview_drive.publish(Float32(data=preview_drive))
        self.pub_preview_wheel.publish(Int32(data=int(round(result.steering_deg))))
        # Actual command topics remain completely silent unless all independent
        # control gates are true. Default launches therefore emit zero vehicle commands.
        if channel_enabled:
            self.pub_drive.publish(Float32(data=float(requested_drive if allow else 0.0)))
            self.pub_wheel.publish(Int32(data=int(round(result.steering_deg))))
        self.pub_cross.publish(Float32(data=float(result.cross_track_error)))
        self.pub_heading.publish(Float32(data=float(result.heading_error)))
        self.pub_progress.publish(Float32(data=float(result.progress)))
        self.pub_state.publish(String(data=reason))
        diagnostic = DiagnosticArray()
        diagnostic.header.stamp = self.get_clock().now().to_msg()
        diagnostic.status = [status(
            "depth_slam/route_follower",
            DiagnosticStatus.WARN if result.stop_required or stale else DiagnosticStatus.OK,
            reason,
            (("cross_track_error_m", result.cross_track_error),
             ("heading_error_rad", result.heading_error),
             ("steering_deg", result.steering_deg),
             ("actual_command_published", allow)))]
        self.pub_diag.publish(diagnostic)
        if self.route:
            point = self.route[result.target_index]
            target = PointStamped()
            target.header.frame_id = "map"
            target.header.stamp = self.get_clock().now().to_msg()
            target.point.x, target.point.y = point.x, point.y
            self.pub_target.publish(target)


def main(args=None):
    rclpy.init(args=args)
    node = RouteFollowerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        safe_shutdown()
