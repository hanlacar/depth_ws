"""Ackermann pure-pursuit route follower with T870 steering convention."""

import math

from .geometry import wrap_angle
from .models import ControllerResult


class RouteFollower:
    def __init__(self, wheelbase=0.58, max_steering_deg=27.0,
                 lookahead_m=0.7, corridor_m=1.0,
                 max_heading_deg=80.0, steering_rate_deg_s=90.0):
        self.wheelbase = float(wheelbase)
        self.max_steering = float(max_steering_deg)
        self.lookahead = float(lookahead_m)
        self.corridor = float(corridor_m)
        self.max_heading = math.radians(max_heading_deg)
        self.steering_rate = float(steering_rate_deg_s)
        self.last_steering = 0.0

    def _nearest(self, pose, route):
        return min(range(len(route)), key=lambda i:
                   (route[i].x-pose.x)**2 + (route[i].y-pose.y)**2)

    def compute(self, pose, route, dt=1.0/30.0, allow_motion=False):
        if not route:
            return ControllerResult(0.0, 0.0, 0, 0, 0.0, 0.0, 0.0,
                                    True, "EMPTY_ROUTE")
        nearest = self._nearest(pose, route)
        cross_track = math.hypot(route[nearest].x-pose.x,
                                 route[nearest].y-pose.y)
        target = nearest
        accumulated = 0.0
        while target + 1 < len(route) and accumulated < self.lookahead:
            a, b = route[target], route[target+1]
            accumulated += math.hypot(b.x-a.x, b.y-a.y)
            target += 1
        point = route[target]
        alpha = wrap_angle(math.atan2(point.y-pose.y, point.x-pose.x)-pose.yaw)
        heading_error = wrap_angle(route[nearest].yaw-pose.yaw)
        stop_reason = ""
        if cross_track > self.corridor:
            stop_reason = "CORRIDOR_VIOLATION"
        elif abs(heading_error) > self.max_heading:
            stop_reason = "HEADING_ERROR"
        elif nearest == len(route)-1 and cross_track < 0.15:
            stop_reason = "ROUTE_COMPLETE"
        elif str(point.mission_marker).upper() in ("STOP", "STOP_POINT") and \
                math.hypot(point.x-pose.x, point.y-pose.y) < 0.3:
            stop_reason = "ROUTE_STOP_POINT"
        # REP-103 is left-positive. T870 command is explicitly right-positive.
        standard = math.degrees(math.atan2(
            2.0*self.wheelbase*math.sin(alpha), max(self.lookahead, 0.05)))
        requested = max(-self.max_steering, min(self.max_steering, -standard))
        curvature_limited = abs(standard) > self.max_steering
        slew = self.steering_rate * max(0.0, dt)
        steering = max(self.last_steering-slew,
                       min(self.last_steering+slew, requested))
        self.last_steering = steering
        stop = bool(stop_reason) or not allow_motion
        reason = stop_reason or ("CONTROL_NOT_APPROVED" if not allow_motion else
                                 ("CURVATURE_SLOWDOWN" if curvature_limited else "OK"))
        drive = 0.0 if stop else float(point.drive_level) * point.direction
        if curvature_limited and not stop:
            drive *= 0.5
        return ControllerResult(
            drive, steering, nearest, target, cross_track, heading_error,
            nearest/max(1, len(route)-1), stop, reason)
