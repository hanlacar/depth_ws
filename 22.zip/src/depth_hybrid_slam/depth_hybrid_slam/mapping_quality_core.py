"""ROS-independent mapping input quality and readiness state machine."""

from collections import deque
import math


class StreamTiming:
    def __init__(self, window_seconds=2.0):
        self.window_seconds = float(window_seconds)
        self.stamps = deque()
        self.last_stamp_ns = None
        self.count = 0
        self.duplicates = 0
        self.backwards = 0

    def observe(self, stamp_ns):
        stamp_ns = int(stamp_ns)
        if self.last_stamp_ns is not None:
            if stamp_ns == self.last_stamp_ns:
                self.duplicates += 1
            elif stamp_ns < self.last_stamp_ns:
                self.backwards += 1
        self.last_stamp_ns = stamp_ns
        self.count += 1
        seconds = stamp_ns / 1.0e9
        self.stamps.append(seconds)
        while self.stamps and seconds - self.stamps[0] > self.window_seconds:
            self.stamps.popleft()

    @property
    def fps(self):
        if len(self.stamps) < 2:
            return 0.0
        duration = self.stamps[-1] - self.stamps[0]
        return (len(self.stamps) - 1) / duration if duration > 0 else 0.0


class RunningMetric:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.minimum = None
        self.maximum = None
        self.latest = None

    def observe(self, value):
        value = float(value)
        self.count += 1
        self.total += value
        self.minimum = value if self.minimum is None else min(self.minimum, value)
        self.maximum = value if self.maximum is None else max(self.maximum, value)
        self.latest = value

    def report(self):
        return {
            "count": self.count,
            "latest": self.latest,
            "mean": self.total / self.count if self.count else None,
            "min": self.minimum,
            "max": self.maximum,
        }


class MappingQuality:
    STREAMS = ("rgb", "depth", "odometry")

    def __init__(self, thresholds):
        self.thresholds = dict(thresholds)
        self.timing = {name: StreamTiming() for name in self.STREAMS}
        self.metrics = {name: RunningMetric() for name in (
            "blur_score", "depth_valid_ratio", "overexposed_ratio",
            "underexposed_ratio", "rtabmap_latency_ms", "rtabmap_inliers",
        )}
        self.tracking = False
        self.tracking_since = None
        self.tracking_true = 0
        self.tracking_total = 0
        self.reset_start = None
        self.reset_current = None
        self.invalid_session = False
        self.pose_jump = False
        self.previous_pose = None
        self.rtabmap_seen = False

    def observe_stream(self, name, stamp_ns):
        self.timing[name].observe(stamp_ns)

    def observe_tracking(self, value, now):
        value = bool(value)
        self.tracking_total += 1
        self.tracking_true += int(value)
        if value and not self.tracking:
            self.tracking_since = float(now)
        elif not value:
            self.tracking_since = None
        self.tracking = value

    def observe_reset(self, value):
        value = int(value)
        if self.reset_start is None:
            self.reset_start = value
        self.reset_current = value
        if value > self.reset_start:
            self.invalid_session = True

    def observe_pose(self, stamp_ns, x, y, yaw):
        self.observe_stream("odometry", stamp_ns)
        current = (float(x), float(y), float(yaw))
        if self.previous_pose is not None:
            distance = math.hypot(current[0] - self.previous_pose[0],
                                  current[1] - self.previous_pose[1])
            rotation = abs(math.atan2(
                math.sin(current[2] - self.previous_pose[2]),
                math.cos(current[2] - self.previous_pose[2])))
            if (distance > float(self.thresholds["pose_jump_translation_m"]) or
                    rotation > float(self.thresholds["pose_jump_rotation_rad"])):
                self.pose_jump = True
        self.previous_pose = current

    def observe_rtabmap(self, latency_ms, inliers=None):
        self.rtabmap_seen = True
        if latency_ms is not None:
            self.metrics["rtabmap_latency_ms"].observe(latency_ms)
        if inliers is not None:
            self.metrics["rtabmap_inliers"].observe(inliers)

    def state(self, now, odometry_publishers, tf_available, database_opened):
        reasons = []
        if self.invalid_session:
            return False, "INVALID_SESSION", ["RESET_COUNT_INCREASED"]
        if self.pose_jump:
            return False, "POSE_JUMP", ["ODOMETRY_POSE_JUMP"]
        if not self.tracking:
            return False, "TRACKING_LOST", ["TRACKING_VALID_FALSE"]
        if int(odometry_publishers) != 1:
            reasons.append(f"ODOMETRY_PUBLISHER_COUNT:{int(odometry_publishers)}")
        for name in self.STREAMS:
            timing = self.timing[name]
            if timing.count == 0:
                reasons.append(name.upper() + "_MISSING")
            if timing.duplicates:
                reasons.append(name.upper() + "_DUPLICATE_TIMESTAMP")
            if timing.backwards:
                reasons.append(name.upper() + "_BACKWARDS_TIMESTAMP")
        minimums = {
            "rgb": "minimum_rgb_fps",
            "depth": "minimum_depth_fps",
            "odometry": "minimum_odometry_fps",
        }
        for name, setting in minimums.items():
            if self.timing[name].fps < float(self.thresholds[setting]):
                reasons.append(name.upper() + "_FPS_LOW")
        if self.thresholds.get("require_reset_zero") and self.reset_current != 0:
            reasons.append("RESET_COUNT_NOT_ZERO")
        if self.tracking_since is None or float(now) - self.tracking_since < float(
                self.thresholds["ready_tracking_seconds"]):
            reasons.append("TRACKING_NOT_STABLE")
        if self.thresholds.get("require_tf_chain") and not tf_available:
            reasons.append("TF_CHAIN_UNAVAILABLE")
        if not self.rtabmap_seen:
            reasons.append("RTABMAP_INFO_MISSING")
        if not database_opened:
            reasons.append("EXPECTED_DB_NOT_OPENED")
        latency = self.metrics["rtabmap_latency_ms"].latest
        if latency is not None and latency > float(
                self.thresholds["maximum_rtabmap_latency_ms"]):
            return False, "OVERLOADED", [f"RTABMAP_LATENCY_MS:{latency:.3f}"] + reasons
        for metric, setting, state in (
                ("blur_score", "minimum_blur_score", "WARN_BLUR"),
                ("depth_valid_ratio", "minimum_depth_valid_ratio", "WARN_DEPTH")):
            limit = self.thresholds.get(setting)
            value = self.metrics[metric].latest
            if limit is not None and value is not None and value < float(limit):
                return False, state, [f"{metric.upper()}:{value:.6f}"] + reasons
        if reasons:
            if any("TIMESTAMP" in reason for reason in reasons):
                return False, "INVALID_SESSION", reasons
            return False, "INITIALIZING", reasons
        return True, "READY", []

    def report(self):
        reset_increase = 0
        if self.reset_start is not None and self.reset_current is not None:
            reset_increase = self.reset_current - self.reset_start
        return {
            "streams": {name: {
                "count": timing.count,
                "current_fps": timing.fps,
                "duplicate_timestamps": timing.duplicates,
                "backwards_timestamps": timing.backwards,
            } for name, timing in self.timing.items()},
            "metrics": {name: metric.report() for name, metric in self.metrics.items()},
            "tracking_true_percent": (
                100.0 * self.tracking_true / self.tracking_total
                if self.tracking_total else 0.0),
            "reset_start": self.reset_start,
            "reset_current": self.reset_current,
            "reset_increase": reset_increase,
            "invalid_session": self.invalid_session,
            "pose_jump": self.pose_jump,
        }
