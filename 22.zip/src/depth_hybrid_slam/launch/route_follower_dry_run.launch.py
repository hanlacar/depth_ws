"""Fail-closed 30 Hz route follower; never enables MCU control."""

from depth_hybrid_slam.launch_common import common_arguments
from launch import LaunchDescription
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    follower = Node(package="depth_hybrid_slam", executable="route_follower",
                    name="route_follower", output="screen",
                    parameters=[{"route_path": LaunchConfiguration("route_path"),
                                 "enable_control": False, "dry_run": True,
                                 "user_approved": False}])
    return LaunchDescription(common_arguments()+[follower])
