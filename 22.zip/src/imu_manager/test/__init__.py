"""IMU manager tests."""
