"""Camera navigation tests."""
